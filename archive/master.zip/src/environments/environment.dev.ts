export const environment = {
    production: false,
    url_api: 'https://localhost:44325/api/'
};
