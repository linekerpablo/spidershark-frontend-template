export const environment = {
    production: true,
    url_api: 'https://localhost:44325/api/'
};
