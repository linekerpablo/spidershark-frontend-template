export enum RouteUtils {
  Usuarios = 'Usuarios/',
  Lembretes = 'Lembretes/',
  Medidas = 'Medidas/',
  Missoes = 'Missoes/',
  MissoesConcluidasUsuario = 'MissoesConcluidasUsuario/',
  NiveisUsuarios = 'NiveisUsuarios/'
}
