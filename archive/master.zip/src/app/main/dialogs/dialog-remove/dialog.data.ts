export class DialogData {
    remove: boolean;
    title: string;
    question: string;
    no: string;
    yes: string;
    image: string;
}
