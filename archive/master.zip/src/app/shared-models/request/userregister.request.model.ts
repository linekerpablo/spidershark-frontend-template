export interface IUserRegister {
    email: string;
    senha: string;
    genero: string;
}