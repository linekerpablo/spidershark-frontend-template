export interface IAlterarLembrete {
    LembreteId: number;
    UsuarioId: number;
    Descricao: string;
    Hora: string;
    DataCriacao: string;
}