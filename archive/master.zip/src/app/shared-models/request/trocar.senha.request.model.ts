export interface ITrocarSenha {
    email: String;
    senhaAntiga: String;
    senhaNova: String;
}