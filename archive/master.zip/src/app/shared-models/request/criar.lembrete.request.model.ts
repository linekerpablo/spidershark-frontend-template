export interface ICriarLembrete {
    UsuarioId: number;
    Descricao: string;
    Hora: string;
}