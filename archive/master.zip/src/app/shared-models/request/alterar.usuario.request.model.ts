export interface IAlterarUsuario {
    UsuarioId: number;
    Nome: string;
    Altura: number;
    Objetivo: string;
    Email: string;
    UsuarioInstagram: string;
}