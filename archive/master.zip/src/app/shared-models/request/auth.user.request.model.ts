export class AuthUser {
    Email: string;
    Senha: string;
}