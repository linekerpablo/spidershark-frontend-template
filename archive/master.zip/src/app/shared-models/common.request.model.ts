export class DomainModel {
  Id: string;
  Name: string;
}
