export interface ILembreteResponse {
    LembreteId: number;
    Descricao: string;
    Hora: string;
    DataCriacao: string;
}