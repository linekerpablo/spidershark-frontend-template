export interface IAuthLocalStorage {
    usuarioId: number;
    nome: string;
    email: string;
    fotoDePerfil: string;
}
