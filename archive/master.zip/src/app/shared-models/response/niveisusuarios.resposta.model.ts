export interface INiveisUsuariosResposta {
  nivelId: number;
  descricaoNivelAtual: string;
  descricaoProximoNivel: string;
  imagemNivelAtual: string;
  imagemProximoNivel: string;
  experienciaNivelAtual: number;
  experienciaProximoNivel: number;
  percentualDeQuantoFalta: number;
}