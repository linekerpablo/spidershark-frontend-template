export interface IMissaoDiariaResposta {
  missaoId: number;
  descricao: string;
  concluida: boolean;
  experiencia: number;
  pontuacao: number;
}