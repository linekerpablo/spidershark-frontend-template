export interface ICalculoIMCResposta {
  imc: number;
  descricao: string;
}