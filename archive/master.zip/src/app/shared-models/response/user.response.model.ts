export interface IUserResponse {
    email: string;
    price: string;
}
