export class ResponsePackage {
    Errors: string[];
    Result: object;
}