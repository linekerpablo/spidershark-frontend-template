export interface IUserAuthResponse {
    usuarioId: number;
    nome: string;
    email: string;
    token: string;
    fotoDePerfil: string;
}
